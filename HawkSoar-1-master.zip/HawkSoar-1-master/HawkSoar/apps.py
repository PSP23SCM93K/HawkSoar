from django.apps import AppConfig

class db_connect(AppConfig):
    name = 'db_connect'
    verbose_name = "db_connect"