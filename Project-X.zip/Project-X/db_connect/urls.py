from django.urls import path
from django.contrib.staticfiles.urls import staticfiles_urlpatterns
from . import views

urlpatterns = [
    #path('', views.index, name='index'),
    path('', views.user_registation, name='user_registation'),
]
urlpatterns += staticfiles_urlpatterns()