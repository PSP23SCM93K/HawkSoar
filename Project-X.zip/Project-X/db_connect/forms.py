from django import forms
from django.forms import ModelForm
from db_connect.models import User_register



class User_register_Form(forms.ModelForm):

    Account_Type_choices = ( 
    ("1", "Mentor"),
    ("2", "Tutor"),
    ("3", "Student")
    )
    User_Email = forms.EmailField(label = "Email")
    Password = forms.CharField(label = "Passcode",max_length = "8")
    Account_Type = forms.ChoiceField(choices  = Account_Type_choices)
    class Meta:
        model = User_register
        fields = '__all__'


"""
class InputForm(forms.ModelForm):
    Student_Name = forms.CharField(label='Student_Name', max_length=20)
    A_number = forms.CharField(label = 'CWID', max_length = 9)
    Student_email = forms.EmailField(label = 'Hawk_ID')
    Major = forms.CharField(label = 'Major',max_length = 20)
    
    class Meta:
        model = Student
        fields = '__all__'
"""
