from django.db import models


class User_register(models.Model):
    User_Email = models.EmailField()
    Password = models.CharField(max_length = 10)
    Account_Type = models.CharField(max_length = 10)

'''
class TutorsCourse(models.Model):

    Tid= models.CharField(max_length = 10,blank = True)
    course_id = models.CharField(max_length=10)
    cname = models.CharField(max_length = 20)

class Tutor(models.Model):
    Tid = models.ForeignKey(TutorsCourse,on_delete=models.CASCADE,default="SPMCS587",editable = True)
    name = models.CharField(max_length = 20)
    email = models.CharField(max_length = 100)


class Student(models.Model):
    A_number = models.CharField(max_length = 9)
    Student_Name = models.CharField(max_length = 20)
    Student_email = models.EmailField()
    Major = models.CharField(max_length = 20)


class Assignments(models.Model):
    A_number = models.ForeignKey(Student, on_delete = models.CASCADE)
    Tutor_id= models.ForeignKey(TutorsCourse, on_delete = models.CASCADE, related_name= 'Tutor_id')
    Assignment_Name = models.CharField(max_length= 10)
    Description = models.CharField(max_length = 20)
    Attach = models.CharField(max_length = 10)
    Subject_Status = models.CharField(max_length = 20)


class Events(models.Model):
    event_id = models.CharField(max_length = 10)
    event_name = models.CharField(max_length = 10)
    event_date = models.DateTimeField(auto_now_add=True)


class Has_Events(models.Model):
    A_number = models.ForeignKey(Student,on_delete = models.CASCADE,related_name = 'Student_number')
    event_id = models.ForeignKey(Events, on_delete = models.CASCADE, related_name = 'Eid')
    event_name = models.ForeignKey(Events, on_delete = models.CASCADE,related_name = 'Ename')
    event_date = models.ForeignKey(Events,on_delete = models.CASCADE,related_name = 'Edate')

class course_registered(models.Model):
    A_number = models.ForeignKey(Student,on_delete = models.CASCADE, related_name = 'CWID')
    Course_id = models.CharField(max_length = 10)
    Course_Name = models.CharField(max_length = 20)

'''
