from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from db_connect.forms import User_register_Form


#def index(request):
    #return HttpResponse("Welcome to HawkSoar Application")


def user_registation(request):
    if request.method == 'POST':
        form = User_register_Form(request.POST)
        if form.is_valid():
            form.save()
            #return HttpResponseRedirect('https://colab.research.google.com/drive/1nd_AkZGrZvL7a64h1NG8799L4Y9PkLAy#updateTitle=true&folderId=1QDxCTGE63vgR4zl9_tazvxa1BudCQae0')

    else:
        form = User_register_Form()

    return render(request, 'user_registration.html', {'form': form})