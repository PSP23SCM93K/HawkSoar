from django.shortcuts import render
from django.http import HttpResponse
from django.http import HttpResponseRedirect
from db_connect.forms import InputForm



# Create your views here.
#def index(request):
    #return HttpResponse("Welcome to HawkSoar Application")


def user_registation(request):
    if request.method == 'POST':
        form = InputForm(request.POST)
        if form.is_valid():
            form.save()
            return HttpResponseRedirect('/thanks/')

    else:
        form = InputForm()

    return render(request, 'user_registration.html', {'form': form})