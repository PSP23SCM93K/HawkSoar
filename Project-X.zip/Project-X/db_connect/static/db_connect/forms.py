from django import forms
from django.forms import ModelForm
from db_connect.models import Student
 
# creating a form
class InputForm(forms.ModelForm):
    Student_Name = forms.CharField(label='Student_Name', max_length=20)
    
    A_number = forms.CharField(label = 'CWID', max_length = 9)
    Student_email = forms.EmailField(label = 'Hawk_ID')
    Major = forms.CharField(label = 'Major',max_length = 20)
    
    class Meta:
        model = Student
        fields = '__all__'

